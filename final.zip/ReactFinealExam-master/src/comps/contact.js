import { Fragment, useState, useCallback } from 'react';
import "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/style.css'
import '../styles/style.scss'
import '../styles/style.css.map'

const min = 6


function ContactPage () {
	const [email, setEmail] = useState('')
	const [name, setName] = useState('')
	const [subject, setSubject] = useState('')

	const validateSubmit = useCallback(
		(e) => {
		e.preventDefault()
		if(email.length < min || subject.length < min || name.length < min) {
			alert(`The length of the text is less ${min}-**`)
		} 
		else {
			alert('Message sent')
		}
		},
		[email.length, name.length, subject.length],
	)



    return <body>
		<div class="wrapper">
			<div class="inner">
      <form action="" onSubmit={validateSubmit}>
					<h3>Contact</h3>
					<p>questions</p>
					<label class="form-group">
						<input type="text" class="form-control" value={name} onChange={(e) => setName(e.target.value)}/>
						<span>your name</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="text" value={email} onChange={(e) => setEmail(e.target.value)} class="form-control"/>
						<span for="">Email</span>
						<span class="border"></span>
					</label>
					<label class="form-group" >
						<textarea name="" id="" class="form-control" style={{ height: "200px" }} onChange={(e) => setSubject(e.target.value)}>{subject}</textarea>
						<span for="">Message</span>
						<span class="border"></span>
					</label>
					<button>Send 
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
				</form>
			</div>
		</div>
		
	</body>
  }

export default ContactPage;