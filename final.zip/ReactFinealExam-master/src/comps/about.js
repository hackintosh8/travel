import { Fragment } from 'react';
import { Route, Switch, withRouter, Link, useHistory, BrowserRouter } from 'react-router-dom';
import '../styles/about.css'
import team1 from '../img/team1.jpg'
import team2 from '../img/team2.jpg'
import team3 from '../img/team3.jpg'
import walpaper from '../img/walpaper.jpg'


const AboutPage = withRouter(({history}) => {
    return <body>
        <div style={{backgroundImage:"url("+ walpaper + ")"}} class="about-section">
            <h1>lorem ipsum</h1>
            <p>Lorem ipsum dolor, sit amet.</p></p>
        </div>
    
        {textAlign:'center'}
        Lorem, ipsum dolor.</h2>

        <div class="row">
            <div class="column">
                <img src={team1} alt="Jane" style={{width:'100%'}}/>
                <div style={{color:'black'}} class="container">
                    <h2>john Doe</h2>
                    <p class="title">CEO & Founder</p>
                    <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                    <p>jane@example.com</p>
                    <p><button onClick={() => { history.push("/contact") }} class="button">lorem ipsum</button></p>
                </div>
            </div>

            <div class="column">
                <img src={team2} alt="lorem" style={{width:'100%'}}/>
                <div style={{color:'black'}} class="container">
                    <h2>Mike Ross</h2>
                    <p class="title">lorem ipsum</p>
                    <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                    <p>loremipsum@example.com</p>
                    <p><button onClick={() => { history.push("/contact") }}  class="button">loremipsum</button></p>
                </div>
            </div>
        
            <div class="column">
                <img src={team3} alt="John" style={{width:'100%'}}/>
                <div style={{color:'black'}} class="container">
                    <h2>John Doe</h2>
                    <p class="title">Designer</p>
                    <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                    <p>john@example.com</p>
                    <p><button onClick={() => { history.push("/contact") }} class="button">lorem ipsum</button></p>
                </div>
            </div>
        </div>
        
        
    </body>
  })

export default AboutPage;